#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
领域知识站 · 英文缩写首次出现处补全英文全称注记。

用法：
  python3 acronym-insert.py <目录>            # 在目录内对 ch*.html + index.html 插入注记
  python3 acronym-insert.py <目录> --check    # 仅扫描，输出未注记的缩写（ALL CLEAN 即合格）
  python3 acronym-insert.py file1.html file2.html

规则（用户硬要求）：
  英文缩写首次在「正文（非 HTML 标签/属性/SVG text）」出现时，补：
      ACRO（Full English Name，中文译名）
  例：VIE（Variable Interest Entity，可变利益实体）

致命坑（已踩过）：
  注记文本里绝不能含其他裸缩写！例如给 18C 写 "HKEX Listing Rules"，
  后续 HKEX 扫描会嵌套进注记，产生重复乱码。本 MAP 一律拼全称
  （"Hong Kong Exchanges and Clearing Limited"）规避，不在注记里留裸缩写。
"""
import re
import sys
import glob
import os

# ===== 缩写 -> 注记全文（请勿在注记里嵌入其他裸缩写）=====
MAP = {
    "VIE": "Variable Interest Entity，可变利益实体",
    "DD": "Due Diligence，尽职调查",
    "VDR": "Virtual Data Room，虚拟资料室",
    "R&W": "Representations and Warranties，陈述与保证",
    "CP": "Conditions Precedent，先决条件",
    "VAM": "Valuation Adjustment Mechanism，估值调整机制（俗称“对赌”）",
    "WVR": "Weighted Voting Rights，同股不同权（不同投票权）",
    "GEM": "Growth Enterprise Market，创业板",
    "ODI": "Overseas Direct Investment，境外直接投资",
    "SPV": "Special Purpose Vehicle，特殊目的载体",
    "WFOE": "Wholly Foreign-Owned Enterprise，外商独资企业",
    "BVI": "British Virgin Islands，英属维尔京群岛",
    "ESOP": "Employee Stock Ownership Plan，员工持股计划",
    "LP": "Limited Partner，有限合伙人",
    "GP": "General Partner，普通合伙人",
    "LPA": "Limited Partnership Agreement，有限合伙协议",
    "MFN": "Most Favoured Nation，最惠国（条款）",
    "KPI": "Key Performance Indicator，关键绩效指标",
    "SPA": "Share Purchase Agreement，股权收购协议",
    "SHA": "Shareholders' Agreement，股东协议",
    "ROFR": "Right of First Refusal，优先购买权",
    "ROFO": "Right of First Offer，优先谈判权",
    "NDA": "Non-Disclosure Agreement，保密协议",
    "KYC": "Know Your Customer，客户身份识别（尽职调查）",
    "AML": "Anti-Money Laundering，反洗钱",
    "SAFE": "State Administration of Foreign Exchange，国家外汇管理局",
    "SAMR": "State Administration for Market Regulation，国家市场监督管理总局",
    "HKEX": "Hong Kong Exchanges and Clearing Limited，香港交易及结算所有限公司（港交所）",
    "SFC": "Securities and Futures Commission，证券及期货事务监察委员会（香港证监会）",
    "IPO": "Initial Public Offering，首次公开募股（即上市）",
    "AGM": "Annual General Meeting，年度股东大会",
    "EBITDA": "Earnings Before Interest, Taxes, Depreciation and Amortization，息税折旧摊销前利润",
    "EBIT": "Earnings Before Interest and Taxes，息税前利润",
    "MAC": "Material Adverse Change，重大不利变化",
    "FOZ": "Fully-Diluted，完全摊薄后",
    "PIPL": "Personal Information Protection Law，《个人信息保护法》",
    "TS": "Term Sheet，投资条款清单",
    "JV": "Joint Venture，合资企业",
    "FDI": "Foreign Direct Investment，外商直接投资",
    "MOFCOM": "Ministry of Commerce，商务部",
    "PE": "Private Equity，私募股权",
    "VC": "Venture Capital，风险投资",
    "IRR": "Internal Rate of Return，内部收益率",
    "ROE": "Return on Equity，净资产收益率",
    "18A": "Chapter 18A of the Hong Kong Exchanges and Clearing Limited Listing Rules，港股《上市规则》第18A章（未盈利生物科技公司上市通道）",
    "18C": "Chapter 18C of the Hong Kong Exchanges and Clearing Limited Listing Rules，港股《上市规则》第18C章（特专科技公司上市通道）",
    # 用时按需往这里加（保持「注记内不嵌裸缩写」原则）
}

ANN_RE = re.compile(r'（[A-Za-z][^）]*[A-Za-z][^）]*）')


def make_re(a):
    if a.isalnum():
        return re.compile(r'(?<![A-Za-z0-9])' + re.escape(a) + r'(?![A-Za-z0-9])')
    return re.compile(re.escape(a))


RE_MAP = {a: make_re(a) for a in MAP}


def inside_tag(txt, pos):
    """判断 pos 是否落在某个 HTML 标签内部（< ... > 之间）。"""
    i = pos - 1
    while i >= 0:
        c = txt[i]
        if c == '>':
            return False
        if c == '<':
            return True
        i -= 1
    return False


def annotate_file(path, do_write=True):
    txt = open(path, encoding="utf-8").read()
    cnt = 0
    for a, full in MAP.items():
        rx = RE_MAP[a]
        m = None
        for mm in rx.finditer(txt):
            if not inside_tag(txt, mm.start()):
                m = mm
                break
        if not m:
            continue
        s, e = m.start(), m.end()
        after = txt[e:e + 120]
        if "（" in after and ANN_RE.search(after):
            continue  # 已注记
        txt = txt[:e] + "（" + full + "）" + txt[e:]
        cnt += 1
    if do_write and cnt:
        open(path, "w", encoding="utf-8").write(txt)
    return cnt


def check_file(path):
    txt = open(path, encoding="utf-8").read()
    miss = []
    for a in MAP:
        m = None
        for mm in RE_MAP[a].finditer(txt):
            if not inside_tag(txt, mm.start()):
                m = mm
                break
        if not m:
            continue
        after = txt[m.end():m.end() + 120]
        if "（" in after and ANN_RE.search(after):
            continue
        miss.append(a)
    return miss


def collect(paths):
    files = []
    for p in paths:
        if os.path.isdir(p):
            files += sorted(glob.glob(os.path.join(p, "ch*.html")))
            f = os.path.join(p, "index.html")
            if os.path.exists(f):
                files.append(f)
        elif os.path.isfile(p):
            files.append(p)
    return files


def main():
    args = sys.argv[1:]
    check = False
    if "--check" in args:
        check = True
        args.remove("--check")
    if not args:
        args = ["."]
    files = collect(args)
    if not files:
        print("未匹配到文件（默认匹配 ch*.html 与 index.html）")
        return

    if check:
        any_miss = False
        for f in files:
            m = check_file(f)
            if m:
                any_miss = True
                print(f"{os.path.basename(f)}: MISS -> {', '.join(m)}")
        print("ALL CLEAN" if not any_miss else "STILL MISS ABOVE")
        return

    total = 0
    for f in files:
        c = annotate_file(f, do_write=True)
        if c:
            print(f"{os.path.basename(f)}: +{c}")
            total += c
    print(f"TOTAL insertions: {total}")


if __name__ == "__main__":
    main()
