---
name: domain-knowledge-static-site
version: 1.0.0
display_name: 国风知识站生成器
display_name_en: Guofeng Knowledge Site Generator
description_zh: 非程序员也能把法律/金融/医学等专业内容，做成带目录、大白话对话、原地展开详解的国风交互知识站。
description_en: Turn professional knowledge (legal, finance, medical, etc.) into an interactive Chinese-style knowledge static site with fixed sidebar TOC, plain-language dialogues, and in-place expandable deep-dives.
description: 把任意专业领域（法律/金融/医学/财税/工程…）写成「国风知识型静态站」：左侧固定可折叠目录栏 + 顶栏搜索/深浅色/全屏 + 右栏本页目录 + 原地展开详解/协议模板/法务对话/生活比方/行内注释/术语卡/案例卡。复制 references/ 里的 style.css 与 app.js 即可获得与「融资法务」站完全一致的交互与视觉。当用户说「做一个 XX 知识站/专题站/把某领域写成网站」时使用。部署到 linqiongni.top 的 tab 时，配套使用 legal-domain-site-tab 技能。
agent_created: true
---

# 领域知识型静态站（国风组件库）

一句话：**复制 `references/style.css` + `references/app.js`，按本 skill 的组件配方写 N 个 HTML 页面，就能产出与「融资法务」站同款的知识型站点**——左栏固定可折叠目录、内容里随处可点开的「大白话对话 / 生活比方 / 原地展开详解 / 协议模板 / 行内注释」。

核心价值不是「能写 HTML」，而是把**已被验证的「翻译层」交互范式**打包好，让任何专业内容都自带：小白读得懂（对话+比方+注释）、从业者查得到（术语卡+案例+模板）、爱深挖的人能展开（peek/tpl/deep）。

## 一、交付物结构

```
<topic>/                       # 源站根目录（唯一真源，改这里）
├── index.html                 # 总纲：地图 + 免责 + 案例主线说明
├── ch01-xxx.html ... chNN.html  # 各知识站（每页只需写正文，框架由 app.js 注入）
└── assets/
    ├── style.css              # ← 复制 references/style.css
    └── app.js                # ← 复制 references/app.js（改 STATIONS 数组即可）

public/<slug>/                 # 若部署到 linqiongni.top，这是 rsync 副本（非源）
```

> 关键约定（与 legal-domain-site-tab 一致）：**源站 = `<topic>/` 中文目录，副本 = `public/<slug>/`。只改源站，再用同步脚本复制到副本。**

## 二、三步落地

1. **建目录 + 复制组件**：`mkdir -p <topic>/assets && cp references/style.css references/app.js <topic>/assets/`
2. **填 STATIONS 数组**（在 `app.js` 顶部）：每个页面一项 `{id, file, no, t, part, kw}`。`id` 与 `<body data-station="...">` 对应；`part` 决定左栏分组；`kw` 用于顶栏搜索。
3. **写页面**：每页套用「station-template.html」骨架，用下方组件配方填内容。

改版细节（品牌名、localStorage key、左栏底部「法源基准」）在 `app.js` 里搜 `fin-legal` / `融资法务` 即可定位。

## 三、页面骨架（每个站必须这样开头/结尾）

```html
<!DOCTYPE html>
<html lang="zh-CN" data-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>01 标题 ｜ 主题名</title>
<link rel="stylesheet" href="assets/style.css?v=20260921">
</head>
<body data-station="ch01">        <!-- 与 STATIONS 的 id 对应 -->
<div id="topbar"></div>             <!-- 占位，app.js 会注入真顶栏+左栏 -->
<div class="wrap">

  <div class="hero">
    <div class="kicker">STATION 01 · ENGLISH TAG</div>
    <h1>页面主标题</h1>
    <p class="sub">一句话导语，点明本页解决什么、主线剧情推进到哪。</p>
    <div class="meta-line"><span>主线标注</span><span>含 N 组对话</span><span>含 N 处比方</span></div>
  </div>

  <!-- 正文：story / h2 / h3 / p / .say / .callout / .dlg / .peek / .tpl / .case / .terms / .lawref / table 等 -->

  <div id="pager"></div>
</div>
<footer class="site">主题名 · 第 01 站 ｜ 主线案例为教学虚构</footer>
<script src="assets/app.js?v=20260921"></script>
</body>
</html>
```

app.js 会自动：注入顶栏（品牌/搜索/当前章/全屏/深浅色/目录按钮）、左侧分组目录栏（可折叠、可搜索、滚动定位）、右侧本页目录（宽屏）、阅读进度条、上下篇翻页、折叠控件、知识锚点跳转。**你只需保证 `<body data-station>` 正确、正文语义标签（h2/h3）清晰即可。**

## 四、组件配方（复制即用）

> 所有组件走 CSS 变量，深浅色自动适配；移动端窄屏自动把左栏变抽屉、右栏落到页内 `.toc`。

### 1. 剧情条（主线叙事）`.story`
```html
<div class="story"><span class="tag">剧情 · Y3</span>
  <p>用一家虚构公司/人物串起全站，<em>重点句用 em 高亮</em>。</p>
</div>
```

### 2. 法务对话体（大白话）`.dlg`
老板/投资人只说人话，法务先用人话答、再翻条款。**这是全站「翻译层」的核心。**
```html
<details class="dlg" open>
  <summary><span class="pk-badge d">对照表</span>展开：黑话 → 人话</summary>
  <div class="dlg-bd">
    <div class="dlg-line boss"><div class="who">老板</div><p class="utt">「这不就是保本吗？」</p></div>
    <div class="dlg-line me"><div class="who">法务</div><p class="utt">「是，但<em>境内法院不一定这么认</em>。」</p></div>
    <div class="dlg-note"><span class="nt">条款翻译</span>
      <p>对应条款原文……<b>注意</b>：站在哪一侧决定了写法不同。</p>
    </div>
  </div>
</details>
```
对话角色类：`.boss`（琥珀色，老板/业务）、`.inv`（蓝色，投资人/外部）、`.me`（绿色，法务/你）。

### 3. 一句话白话 `.plain`（放在 h3 下方先给结论）
```html
<h3>清算优先权</h3>
<p class="plain"><span class="pl">大白话：</span>分家产时，他排你前面先搬走本金，再回来跟你一起分。</p>
```

### 4. 生活比方 `.sim`（紧跟法律句后）
```html
<p>减资是回购对赌的前置程序，走不完法院驳回起诉。<span class="sim"><b>就好比：</b>你想把房本上的名字去掉，<em>得先还清房贷</em>，银行不点头就过不了户。</span></p>
```

### 5. 比喻框 `.say`（独立大比方）
```html
<div class="say"><span class="lbl">大白话打比喻</span>
  <p class="analogy">这套体系好比盖一栋从画图纸到挂招牌的楼……</p>
</div>
```

### 6. 行内注释 `.anno`（悬停看白话，不跳走）
```html
<span class="anno" title="指公司把股本退回股东的法定程序，须通知债权人并公告">减资</span>
```

### 7. 提示框 `.callout`
```html
<div class="callout c-tip"><span class="lbl">先看这段</span><p>……</p></div>
<!-- c-warn 红（红线/坑） / c-tip 绿（建议） / c-law 蓝（法条/依据） -->
```

### 8. 术语卡 `.terms`（首页或每页速查）
```html
<div class="terms">
  <div class="term"><div class="tw"><span class="zh">持股平台</span><span class="en">Holding Platform</span></div>
    <div class="def">通常为<b>有限合伙企业</b>：创始人当 GP……</div></div>
</div>
```

### 9. 原地展开详解 `.peek`（点开就在本节下方，不跳转）
```html
<details class="peek">
  <summary><span class="pk-badge k">常见坑</span><span class="pk-badge t">术语</span>清算优先权怎么设？</summary>
  <div class="pk-bd">
    <h4>大白话</h4><p>……</p>
    <h4>专业术语</h4><p>……</p>
    <h4>条款解析</h4><p>……</p>
  </div>
</details>
```
徽章类：`.k` 红（常见坑）、`.t` 蓝（术语）、`.d` 金（大白话/对照）。可在页顶放 `.tplbar` 一键展开/收起全部 `peek`/`tpl`/`dlg`：
```html
<div class="tplbar">
  <span>本页均为原地展开：</span>
  <button type="button" data-fold="open" data-fold-kind="peek">展开全部详解</button>
  <button type="button" data-fold="close" data-fold-kind="peek">收起全部详解</button>
  <button type="button" data-fold="open" data-fold-kind="tpl">展开全部模板</button>
</div>
```

### 10. 可折叠协议模板 `.tpl`（含 `.clause` 模板正文）
```html
<details class="tpl">
  <summary><div class="ch">条款 F · 回购义务双层写法</div><span class="cue"></span></summary>
  <div class="clause">
    <div class="ch">条款 F · 回购义务的双层写法</div>
    <div class="zh">若发生任一回购触发事件……</div>
  </div>
</details>
```

### 11. 案例卡 `.case`（含正反对照 `.vs`）
```html
<div class="case"><div class="hd">案例：华工案 vs 海富案</div>
  <div class="bd">
    <div class="vs">
      <div class="vsa"><div class="vsh">✗ 海富（与目标公司对赌）</div><p>最高法院认定无效……</p></div>
      <div class="vsb"><div class="vsh">✓ 华工（与股东对赌）</div><p>有效……</p></div>
    </div>
  </div>
</div>
```

### 12. 深度补充（可跳转）`.deep` + `.xref`（内容多、需跨页锚定）
```html
<p>详情见<a class="xref" data-deep="deep-lp">有限合伙企业<span>详解</span></a>。</p>
<details class="deep" id="deep-lp">
  <summary><span class="seal-sm">深</span><span class="dtitle">有限合伙企业持股平台全解</span>
    <span class="dmeta">大白话 · 术语 · 条款 · 模板</span><span class="dcue"></span></summary>
  <div class="deep-bd">……</div>
</details>
```

### 13. 表格 `.tw` / 法条索引 `.lawref` / 时间轴 `.timeline` / 数据 `.stat`
见 `references/style.css` 对应类；`.tw` 已含横向滚动，`table` 用 `min-width` 保证手机不挤。

## 五、硬规则（用户重申，必须遵守）

**英文缩写首次出现必须带英文全称注记**，格式 `ACRO（Full English Name，中文）`：
> `VIE（Variable Interest Entity，可变利益实体）`、`ODI（Overseas Direct Investment，境外直接投资）`、`18C（Chapter 18C of the Hong Kong Exchanges and Clearing Limited Listing Rules，港股《上市规则》第18C章（特专科技公司上市通道））`

- 用 `references/acronym-insert.py` 批量补注：传入目录即可在**正文首次出现处**自动插入（跳过 HTML 标签/SVG text/属性，已注记的不再重复）。
- **致命坑**：注记文本里**绝不能含其他裸缩写**（如 18C 注记里写 "HKEX Listing Rules" 会被后续 HKEX 扫描嵌套，产生重复乱码）。要么拼全称（"Hong Kong Exchanges and Clearing Limited"），要么把该注记排除在扫描外。
- 跑完脚本必须再跑一次「ALL CLEAN」扫描确认无遗漏、且标签配平。
- **换领域时必须换 MAP**：脚本自带的 MAP 只有融资领域缩写。做法：`cp references/acronym-insert.py /tmp/acronym-<领域>.py`，替换整个 MAP 为本领域词条后再跑（已用于跨境物流站：NVOCC / B/L / FCL / LCL / SDR / HS / AEO / GPSR / CE / UKCA / EPR / WEEE / REACH / DPA / GDPR / ERP / WMS / MTO / CMR / KP / Incoterms / FOB / CIF / DAP / DDP / HKIAC / SIAC / OFAC…）。
- **歧义短缩写不要进 MAP**（会插错地方）：`CE`、`GA`、`ICC`、`CO`、`CAD`、`LP`、`TS` 等 2–3 字母词在不同领域含义不同，交给人工在首次出现处手写。
- 注记里的中文补充说明别再套一层全角括号（如 `金伯利进程（毛坯钻石国际证书制度）` 嵌套在 `KP（…）` 里读起来很怪），写成 `金伯利进程国际毛坯钻石证书制度` 更干净。

## 六、内容写法铁律（来自融资法务站的验证）

1. **一条故事线串全站**：虚构一家公司与人物（如「霓光珠宝」），每页推进剧情，散知识点变连贯。
2. **每页四件套**：①剧情条 ②黑话→人话对照表 ③核心条款的「法务对话」 ④难句后的「生活比方」。
3. **翻译优先于专业**：先让小白读懂（对话+比方+注释），再给条款与模板。
4. **法条/数字标出处 + 复核提示**：条号写「依 ×× 年修订本，以现行文本为准」；量化门槛联网核校，页内置「法源基准」栏。
5. **站在不同侧给不同写法**：投资人侧/公司侧/创始人侧模板分开，标注「站在哪一侧」。

## 七、部署

- **本地纯静态**：`<topic>/` 直接用任意静态服务器打开，零外部依赖、零上传。
- **linqiongni.top tab**：用 `legal-domain-site-tab` 技能——`npm run sync:<slug>` 复制到 `public/<slug>/`，改 types/navConfig/App 三处加 iframe tab，tsc，commit 自己文件，push 触发 CI。
- 改源站后**必须重新同步**再 push；并行会话若只改了 `public/` 副本，要从源站改并同步（见 legal-domain-site-tab 的坑）。

## 七·五、批量产出的节奏（10 章以上的站）

- **先手写第 01 章当样板**：hero/story/tplbar/术语卡/表格/8 组 dlg/4 个 peek/案例卡/Checklist/法源栏全套走一遍，后面才有可复制的语感与密度基准。
- **不要一次派多个子代理并行写章**：实测三个 general-purpose 子代理同时写 4 章会触发 429 频率限制，全部失败（已踩）。要么主 agent 逐章写，要么一次只派一个。
- **每章 30–45 KB 是合适密度**：低于 25 KB 会显得空（表格和对话不够），超过 55 KB 加载与滚动手感变差。
- 每写完 3–4 章就跑一次标签栈校验，别等全部写完再查（错误会连片）。

标签栈校验脚本（HTMLParser，可复用）：
```python
from html.parser import HTMLParser
VOID={'meta','link','br','hr','img','input','source','col','wbr'}
class P(HTMLParser):
    def __init__(s): super().__init__(); s.stack=[]; s.err=[]
    def handle_starttag(s,t,a):
        if t not in VOID: s.stack.append((t,s.getpos()))
    def handle_endtag(s,t):
        if t in VOID: return
        if not s.stack: s.err.append(f'extra </{t}>'); return
        if s.stack[-1][0]==t: s.stack.pop()
        else:
            for i in range(len(s.stack)-1,-1,-1):
                if s.stack[i][0]==t: s.err.append(f'unclosed {s.stack[i][0]} line {s.stack[i][1][0]}'); del s.stack[i:]; break
            else: s.err.append(f'stray </{t}>')
```

## 八、验证清单

- [ ] `app.js` 的 STATIONS 与每个 `<body data-station>` 一一对应
- [ ] `acronym-insert.py` 跑过 → 扫描 ALL CLEAN
- [ ] 标签配平（`<details>`/`<div>` 成对）
- [ ] 浏览器实测：左栏折叠、搜索、深浅色、`.tplbar` 一键展开、`.xref` 跳转、手机端 390px 不溢出
- [ ] 部署前 `tsc --noEmit` 通过（仅在有 React 壳时）

## 九、合规与免责（对外发布 / 售卖版必读）

本 skill 生成的站点常涉及法律、金融、医疗等受监管内容，发布到 SkillHub / 对外售卖前务必：

- **页内置免责**：每个生成的站点首页与正文显著位置声明「本内容仅供学习交流，不构成正式法律 / 医疗 / 财务意见，使用前请咨询持牌专业人士」。可复用 `index-template.html` 的免责位。
- **不内嵌真实客户 / 案件材料**：模板与示例一律用虚构主线（如「霓光珠宝」），不携带任何个人、客户、案件的可识别信息。
- **不含密钥**：references/ 内不得出现 token、cookie、API key、账号密码（已扫描确认无）。
- **敏感领域标注**：在 Skill 描述中明确「生成内容需使用者自行合规把关」，规避误导责任。
- **遵循平台审核**：SkillHub 发布走「安全扫描 + AI 审核 + 人工抽检」三关，上述要求也是过审前提。
